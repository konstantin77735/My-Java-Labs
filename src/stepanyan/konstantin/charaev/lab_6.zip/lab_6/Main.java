package danil.charaev.lab_5;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

// Объявляемое исключение InvalidExitDateException
class InvalidExitDateException extends Exception {
    private LocalDate checkInDate;
    private LocalDate checkOutDate;

    public InvalidExitDateException(LocalDate checkInDate, LocalDate checkOutDate) {
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }

    public LocalDate getCheckInDate() {
        return checkInDate;
    }

    public LocalDate getCheckOutDate() {
        return checkOutDate;
    }
}

// Необъявляемое исключение DuplicateVoucherReturningException
class DuplicateVoucherReturningException extends RuntimeException {
    private Putevki returnedVoucher; // Ссылка на путевку, которая уже была ранее возвращена

    public DuplicateVoucherReturningException(Putevki returnedVoucher) {
        this.returnedVoucher = returnedVoucher;
    }

    public Putevki getReturnedVoucher() {
        return returnedVoucher;
    }
}

abstract class Putevki implements Comparable {
    protected int code; // Код путевки
    protected String clientSurname; // Фамилия клиента
    protected String hotelName; // Название пансионата
    protected int roomNumber; // Номер комнаты
    protected String accommodationType; // Вид жилья
    protected String checkInDate; // Дата заезда
    protected String checkOutDate; // Дата выезда
    protected int numberOfPeople; // Количество человек
    protected double price; // Цена

    public Putevki(int code, String clientSurname, String hotelName, int roomNumber, String accommodationType,
                   String checkInDate, String checkOutDate, int numberOfPeople, double price) {
        if (numberOfPeople < 0 || price < 0) {
            throw new IllegalArgumentException("Количество человек и цена должны быть положительными значениями");
        }

        this.code = code;
        this.clientSurname = clientSurname;
        this.hotelName = hotelName;
        this.roomNumber = roomNumber;
        this.accommodationType = accommodationType;
        this.checkInDate = checkInDate.toString();
        this.checkOutDate = checkOutDate.toString();
        this.numberOfPeople = numberOfPeople;
        this.price = price;
    }

    // Сеттер для поля numberOfPeople
    public void setNumberOfPeople(int numberOfPeople) {
        if (numberOfPeople < 0) {
            throw new IllegalArgumentException("Количество человек должно быть положительным значением");
        }
        this.numberOfPeople = numberOfPeople;
    }

    // Сеттер для поля price
    public void setPrice(double price) {
        if (price < 0) {
            throw new IllegalArgumentException("Цена должна быть положительным значением");
        }
        this.price = price;
    }

    // Сеттер для поля checkOutDate с проверкой дат
    public void setCheckOutDate(LocalDate checkOutDate) throws InvalidExitDateException {
        LocalDate _checkInDate = LocalDate.parse(checkInDate);
        if (checkOutDate.isBefore(_checkInDate)) {
            throw new InvalidExitDateException(_checkInDate, checkOutDate);
        }
        this.checkOutDate = checkOutDate.toString();
    }


    // Реализация метода compareTo для сортировки путевок по фамилиям клиентов
    @Override
    public int compareTo(Putevki other) {
        return this.clientSurname.compareTo(other.clientSurname);
    }

    public abstract void printDetails();
}

// Интерфейс "Возвращаемая"
interface Vozvrat {
    void oformitVozvrat();
}

// Интерфейс "Расширяемая"
interface Rashiryaemaya {
    void dobavitDopolnitelnyeUslugi(List<String> uslugi);
}

interface Comparable {
    public int compareTo(Putevki other);
}


class ZarubezhniePutevki extends Putevki {
    private String passportNumber;
    private String insurance;

    public ZarubezhniePutevki(int code, String clientSurname, String hotelName, int roomNumber, String accommodationType,
                              String checkInDate, String checkOutDate, int numberOfPeople, double price,
                              String passportNumber, String insurance) {
        super(code, clientSurname, hotelName, roomNumber, accommodationType, checkInDate, checkOutDate, numberOfPeople, price);
        this.passportNumber = passportNumber;
        this.insurance = insurance;
    }

    @Override
    public void printDetails() {
        System.out.println("Код путевки: " + code);
        System.out.println("Фамилия клиента: " + clientSurname);
        System.out.println("Название пансионата: " + hotelName);
        System.out.println("Номер комнаты: " + roomNumber);
        System.out.println("Вид жилья: " + accommodationType);
        System.out.println("Дата заезда: " + checkInDate);
        System.out.println("Дата выезда: " + checkOutDate);
        System.out.println("Количество человек: " + numberOfPeople);
        System.out.println("Цена: " + price);
        System.out.println("Загран. паспорт: " + passportNumber);
        System.out.println("Страховка: " + insurance);
    }
}

class Sanatorii extends Putevki implements Vozvrat, Rashiryaemaya {
    private String medicalPolicy;
    private String diagnosis;
    private String referral;
    private List<String> additionalServices;

    public Sanatorii(int code, String clientSurname, String hotelName, int roomNumber, String accommodationType,
                     String checkInDate, String checkOutDate, int numberOfPeople, double price,
                     String medicalPolicy, String diagnosis, String referral) {
        super(code, clientSurname, hotelName, roomNumber, accommodationType, checkInDate, checkOutDate, numberOfPeople, price);
        this.medicalPolicy = medicalPolicy;
        this.diagnosis = diagnosis;
        this.referral = referral;
        this.additionalServices = new ArrayList<>();
    }

    @Override
    public void printDetails() {
        System.out.println("Код путевки: " + code);
        System.out.println("Фамилия клиента: " + clientSurname);
        System.out.println("Название пансионата: " + hotelName);
        System.out.println("Номер комнаты: " + roomNumber);
        System.out.println("Вид жилья: " + accommodationType);
        System.out.println("Дата заезда: " + checkInDate);
        System.out.println("Дата выезда: " + checkOutDate);
        System.out.println("Количество человек: " + numberOfPeople);
        System.out.println("Цена: " + price);
        System.out.println("Мед. полис: " + medicalPolicy);
        System.out.println("Диагноз: " + diagnosis);
        System.out.println("Направление: " + referral);
    }

    @Override
    public void oformitVozvrat() {
        System.out.println("Оформление возврата путевки");
        // Код для оформления возврата путевки
    }

    @Override
    public void dobavitDopolnitelnyeUslugi(List<String> uslugi) {
        additionalServices.addAll(uslugi);
    }
}

class DetskieOzdorovitelnie extends Putevki implements Vozvrat {
    private int childAge;
    private String birthCertificateNumber;
    private String gender;

    public DetskieOzdorovitelnie(int code, String clientSurname, String hotelName, int roomNumber, String accommodationType,
                                 String checkInDate, String checkOutDate, int numberOfPeople, double price,
                                 int childAge, String birthCertificateNumber, String gender) {
        super(code, clientSurname, hotelName, roomNumber, accommodationType, checkInDate, checkOutDate, numberOfPeople, price);
        this.childAge = childAge;
        this.birthCertificateNumber = birthCertificateNumber;
        this.gender = gender;
    }

    @Override
    public void printDetails() {
        System.out.println("Код путевки: " + code);
        System.out.println("Фамилия клиента: " + clientSurname);
        System.out.println("Название пансионата: " + hotelName);
        System.out.println("Номер комнаты: " + roomNumber);
        System.out.println("Вид жилья: " + accommodationType);
        System.out.println("Дата заезда: " + checkInDate);
        System.out.println("Дата выезда: " + checkOutDate);
        System.out.println("Количество человек: " + numberOfPeople);
        System.out.println("Цена: " + price);
        System.out.println("Возраст ребенка: " + childAge);
        System.out.println("Свидетельство о рождении: " + birthCertificateNumber);
        System.out.println("Пол: " + gender);
    }

    @Override
    public void oformitVozvrat() {
        System.out.println("Оформление возврата путевки");
        // Код для оформления возврата путевки
    }
}

class PutevkiList {
    private List<Putevki> putevkiList;

    public PutevkiList() {
        putevkiList = new ArrayList<>();
    }

    public void addPutevka(Putevki putevka) {
        putevkiList.add(putevka);
    }

    public void printPutevkiList() {
        for (Putevki putevka : putevkiList) {
            putevka.printDetails();
            System.out.println();
        }
    }
}

public class Main {
    public static void main(String[] args) {
        PutevkiList putevkiList = new PutevkiList();

        ZarubezhniePutevki putevka1 = new ZarubezhniePutevki(1, "Иванов", "Отель ABC", 101, "Стандарт", "2023-07-15", "2023-07-22",
                                                             2, 3000.0, "12345678", "Страховка XYZ");
        Sanatorii putevka2 = new Sanatorii(2, "Петров", "Санаторий Диагностика", 201, "Лечение", "2023-07-20", "2023-07-30",
                                           1, 2000.0, "МедПолис123", "Гастрит", "Направление №456");
        DetskieOzdorovitelnie putevka3 = new DetskieOzdorovitelnie(3, "Сидорова", "Детский лагерь КЛМ", 301, "Коттедж", "2023-08-05", "2023-08-15",
                                                                   1, 1800.0, 10, "BC789012", "Женский");

        putevkiList.addPutevka(putevka1);
        putevkiList.addPutevka(putevka2);
        putevkiList.addPutevka(putevka3);

        putevkiList.printPutevkiList();
    }
}
